// PostgreSQL database layer (replaces better-sqlite3).
//   db.get(sql, params)  -> row | undefined
//   db.all(sql, params)  -> row[]
//   db.run(sql, params)  -> { changes }
//   db.transaction(async (tx) => {...})
// `?` placeholders are converted to $1, $2, ... automatically.
const { Pool, types } = require('pg');
const fs = require('fs');
const path = require('path');

// BIGINT (int8) and COUNT(*) come back from pg as strings by default; parse them to numbers.
types.setTypeParser(20, (v) => parseInt(v, 10));

if (!process.env.DATABASE_URL) {
  console.error('[VØĪD HØSTÏÑG] DATABASE_URL is not set. Add it in Railway: Variables > DATABASE_URL = ${{Postgres.DATABASE_URL}}');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'false' || /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL || '')
    ? false
    : { rejectUnauthorized: false },
  max: parseInt(process.env.PG_POOL_MAX || '10', 10),
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => console.error('[pg] idle client error:', err.message));

function toPositional(sql) {
  let out = '', n = 0, inStr = false;
  for (let i = 0; i < sql.length; i++) {
    const c = sql[i];
    if (c === "'") inStr = !inStr;
    if (c === '?' && !inStr) out += '$' + (++n);
    else out += c;
  }
  return out;
}

function makeApi(q) {
  return {
    query: (sql, params = []) => q(toPositional(sql), params),
    get: async (sql, params = []) => (await q(toPositional(sql), params)).rows[0],
    all: async (sql, params = []) => (await q(toPositional(sql), params)).rows,
    run: async (sql, params = []) => ({ changes: (await q(toPositional(sql), params)).rowCount }),
  };
}

const db = makeApi((sql, params) => pool.query(sql, params));

db.transaction = async (fn) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const tx = makeApi((sql, params) => client.query(sql, params));
    const result = await fn(tx);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

db.init = async () => {
  await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
};

db.syncExpiredPlans = async () => {
  try {
    await db.run(`
      UPDATE users SET plan = 'free'
      WHERE plan = 'premium'
        AND premium_expires_at IS NOT NULL
        AND premium_expires_at <= NOW()
    `);
  } catch {}
};

db.pool = pool;
module.exports = db;
