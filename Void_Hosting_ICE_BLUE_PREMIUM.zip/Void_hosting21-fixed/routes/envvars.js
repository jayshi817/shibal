const { asyncHandler } = require('../utils/asyncHandler');
const express = require('express');
const db = require('../database');
const { requireAuth } = require('../middleware/auth');
const router = express.Router({ mergeParams: true });

async function ownsBot(userId, botId) {
  return (await db.get('SELECT id FROM bots WHERE id = ? AND user_id = ?', [botId, userId]));
}

// GET all env vars for a bot
router.get('/', requireAuth, asyncHandler(async (req, res) => {
  if (!await ownsBot(req.session.userId, req.params.id))
    return res.json({ success: false, message: 'Not found' });
  const vars = (await db.all('SELECT id, key, value FROM bot_env_vars WHERE bot_id = ? ORDER BY key', [req.params.id]));
  res.json({ success: true, vars });
}));

// PUT set/update a var
router.put('/', requireAuth, asyncHandler(async (req, res) => {
  if (!await ownsBot(req.session.userId, req.params.id))
    return res.json({ success: false, message: 'Not found' });
  const { key, value } = req.body;
  if (!key) return res.json({ success: false, message: 'Key is required' });
  if (!/^[A-Z_][A-Z0-9_]*$/i.test(key)) return res.json({ success: false, message: 'Key must be alphanumeric/underscore' });
  (await db.run('INSERT INTO bot_env_vars (bot_id, key, value) VALUES (?, ?, ?) ON CONFLICT(bot_id, key) DO UPDATE SET value = excluded.value', [req.params.id, key.trim().toUpperCase(), value != null ? String(value) : '']));
  res.json({ success: true, message: 'Variable saved' });
}));

// DELETE a var
router.delete('/', requireAuth, asyncHandler(async (req, res) => {
  if (!await ownsBot(req.session.userId, req.params.id))
    return res.json({ success: false, message: 'Not found' });
  const { key } = req.body;
  if (!key) return res.json({ success: false, message: 'Key is required' });
  (await db.run('DELETE FROM bot_env_vars WHERE bot_id = ? AND key = ?', [req.params.id, key.trim().toUpperCase()]));
  res.json({ success: true, message: 'Variable deleted' });
}));

module.exports = router;
