const { asyncHandler } = require('../utils/asyncHandler');
const express = require('express');
const db = require('../database');
const { requireAuth } = require('../middleware/auth');
const { isAdminUser } = require('../middleware/auth');
const router = express.Router();

// GET active announcements (all users)
router.get('/', requireAuth, asyncHandler(async (req, res) => {
  const rows = (await db.all('SELECT * FROM announcements WHERE active = 1 ORDER BY created_at DESC LIMIT 5', []));
  res.json({ success: true, announcements: rows });
}));

// POST new announcement (admin only)
router.post('/', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  if (!isAdminUser(user)) return res.json({ success: false, message: 'Admin access only' });
  const { title, body, photo_url } = req.body;
  if (!title || !body) return res.json({ success: false, message: 'Title and body are required' });
  (await db.run('INSERT INTO announcements (title, body, photo_url, created_by) VALUES (?, ?, ?, ?)', [title.trim(), body.trim(), photo_url ? photo_url.trim() : null, user.username]));
  res.json({ success: true, message: 'Announcement posted' });
}));

// DELETE announcement (admin only)
router.delete('/:id', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  if (!isAdminUser(user)) return res.json({ success: false, message: 'Admin access only' });
  (await db.run('UPDATE announcements SET active = 0 WHERE id = ?', [req.params.id]));
  res.json({ success: true, message: 'Announcement removed' });
}));

module.exports = router;
