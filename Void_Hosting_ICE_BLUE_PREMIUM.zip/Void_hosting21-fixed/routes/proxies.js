const { asyncHandler } = require('../utils/asyncHandler');
// routes/proxies.js — what a regular user can see/do with proxies.
// Admin-side stock management lives in routes/admin.js instead.

const express = require('express');
const db = require('../database');
const { requireAuth } = require('../middleware/auth');
const SHARED_POOL_LIMIT = { free: 500, premium: 5000 };

function limitForPlan(plan) {
  return SHARED_POOL_LIMIT[plan] || SHARED_POOL_LIMIT.free;
}

// Personal (assigned) proxies in full, plus the shared-pool slice capped by plan.
// Dead proxies are never handed out.
async function getUsableProxies(userId, plan) {
  const assigned = await db.all("SELECT * FROM proxies WHERE assigned_user_id = ? AND status = 'alive' ORDER BY id", [userId]);
  const limit = limitForPlan(plan);
  const shared = limit > 0
    ? await db.all("SELECT * FROM proxies WHERE assigned_user_id IS NULL AND status = 'alive' ORDER BY id LIMIT ?", [limit])
    : [];
  return { assigned, shared, limit };
}

function toLine(p) {
  return p.username
    ? `${p.host}:${p.port}:${p.username}:${p.password || ''}`
    : `${p.host}:${p.port}`;
}

// Masks credentials for on-screen display.
function toMaskedLine(p) {
  if (!p.username) return `${p.host}:${p.port}`;
  const u = p.username.length > 3 ? p.username.slice(0, 3) + '••••' : '••••';
  return `${p.host}:${p.port}:${u}:••••••`;
}


const router = express.Router();

// GET /api/proxies — summary + a masked preview of what this account can use
router.get('/', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT id, plan FROM users WHERE id = ?', [req.session.userId]));
  const { assigned, shared, limit } = await getUsableProxies(user.id, user.plan);
  const allProxies = [...assigned, ...shared];
  const aliveCount = allProxies.filter(p => p.status === 'alive').length;
  const deadCount  = allProxies.filter(p => p.status === 'dead').length;
  res.json({
    success: true,
    plan: user.plan,
    shared_limit: limit,
    shared_count: shared.length,
    assigned_count: assigned.length,
    total: allProxies.length,
    alive: aliveCount,
    dead: deadCount,
    preview: allProxies.slice(0, 50).map(toMaskedLine)
  });
}));

// GET /api/proxies/download — the real list, as a .txt file (host:port:user:pass per line)
router.get('/download', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT id, plan FROM users WHERE id = ?', [req.session.userId]));
  const { assigned, shared } = await getUsableProxies(user.id, user.plan);
  const lines = [...assigned, ...shared].map(toLine).join('\n');
  res.setHeader('Content-Disposition', 'attachment; filename="proxies.txt"');
  res.setHeader('Content-Type', 'text/plain');
  res.send((lines || '# No proxies available yet') + '\n');
}));

// POST /api/proxies/request  { message }
router.post('/request', requireAuth, express.json(), asyncHandler(async (req, res) => {
  const pending = (await db.get("SELECT id FROM proxy_requests WHERE user_id = ? AND status = 'pending'", [req.session.userId]));
  if (pending) {
    return res.json({ success: false, message: 'You already have a pending request — sit tight, Nix will get to it.' });
  }
  const message = String((req.body && req.body.message) || '').slice(0, 300);
  (await db.run('INSERT INTO proxy_requests (user_id, message) VALUES (?, ?)', [req.session.userId, message]));
  res.json({ success: true, message: 'Request sent! Nix will assign you more proxies soon.' });
}));

module.exports = router;
