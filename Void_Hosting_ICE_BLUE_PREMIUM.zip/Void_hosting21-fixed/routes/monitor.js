// routes/monitor.js — admin-only live monitor: host stats and a global live log.
// Mounted at /api/admin/monitor (behind requireAdmin).
const express = require('express');
const { asyncHandler } = require('../utils/asyncHandler');
const { requireAdmin } = require('../middleware/auth');
const db = require('../database');
const sysStats = require('../services/sysStats');

const router = express.Router();
router.use(requireAdmin);

// GET /api/admin/monitor/system — CPU, GPU, memory, network, Telegram latency
router.get('/system', asyncHandler(async (req, res) => {
  const stats = await sysStats.snapshot();
  res.json({ success: true, stats });
}));

// GET /api/admin/monitor/logs?since=<id> — newest log lines across all bots.
// Pass the last id you saw to get only new lines.
router.get('/logs', asyncHandler(async (req, res) => {
  const since = parseInt(req.query.since, 10) || 0;
  const rows = since
    ? await db.all('SELECT l.id, l.bot_id, l.message, l.level, l.created_at, b.name AS bot_name FROM logs l LEFT JOIN bots b ON b.id = l.bot_id WHERE l.id > ? ORDER BY l.id ASC LIMIT 200', [since])
    : await db.all('SELECT l.id, l.bot_id, l.message, l.level, l.created_at, b.name AS bot_name FROM logs l LEFT JOIN bots b ON b.id = l.bot_id ORDER BY l.id DESC LIMIT 100', []);
  const ordered = since ? rows : rows.reverse();
  const last = ordered.length ? ordered[ordered.length - 1].id : since;
  res.json({ success: true, logs: ordered, last_id: last });
}));

module.exports = router;
