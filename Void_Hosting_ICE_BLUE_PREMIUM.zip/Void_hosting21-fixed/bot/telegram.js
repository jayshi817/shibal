const TelegramBot = require('node-telegram-bot-api');
const db = require('../database');
const crypto = require('crypto');

let bot = null;
let botUsername = null;
const CHANNEL = process.env.NIXZ_CHANNEL || '@Karl_MainCh';
const CHANNEL_URL = process.env.NIXZ_CHANNEL_URL || `https://t.me/${CHANNEL.replace(/^@/, '')}`;
const SITE_URL = (process.env.NIXZ_URL || 'https://voidhosting21-production.up.railway.app').replace(/\/+$/, '');

function generateToken() {
  return 'VOID-' + crypto.randomBytes(6).toString('hex').toUpperCase();
}

// ── Helpers ──────────────────────────────────────────────────────────────
async function getTelegramId(userId) {
  try {
    const row = (await db.get('SELECT telegram_id FROM activation_tokens WHERE used_by = ? ORDER BY used_at DESC LIMIT 1', [userId]));
    return row ? row.telegram_id : null;
  } catch { return null; }
}

// Sends a message. Errors are logged (never silently swallowed). If Telegram
// rejects the Markdown (usually a stray * _ or ` character), the same message
// is re-sent as plain text so the user still gets a reply.
function send(telegramId, text, extra = {}) {
  if (!telegramId || !bot) return;
  bot.sendMessage(telegramId, text, { parse_mode: 'Markdown', ...extra }).catch((err) => {
    const msg = err.message || '';
    console.error('[Bot] sendMessage failed to', telegramId, ':', msg.slice(0, 140));
    if (/can't parse entities|parse/i.test(msg)) {
      const plain = text.replace(/[*_`]/g, '');
      bot.sendMessage(telegramId, plain, { ...extra, parse_mode: undefined })
        .catch((e2) => console.error('[Bot] plain-text retry failed:', (e2.message || '').slice(0, 140)));
    }
  });
}

async function isChannelMember(userId) {
  if (!bot) return false;
  try {
    const member = await bot.getChatMember(CHANNEL, userId);
    return ['creator', 'administrator', 'member'].includes(member.status);
  } catch (err) {
    console.warn('[Bot] getChatMember failed:', err.message?.slice(0, 100));
    // Fail CLOSED on every error. If the bot isn't an admin of CHANNEL, or the
    // channel username/ID is wrong, we can't verify membership — so we must
    // show the join gate rather than silently letting everyone through.
    if (err.message && /not enough rights|chat not found|bot is not a member/i.test(err.message)) {
      console.error('[Bot] ⚠️ Cannot verify channel membership — is the bot an admin of', CHANNEL, '?');
    }
    return false;
  }
}

function joinChannelKeyboard(refPayload) {
  return {
    inline_keyboard: [
      [{ text: '📢 Join the Channel', url: CHANNEL_URL }],
      [{ text: '✅ I\'ve Joined — Continue', callback_data: `check_join:${refPayload || ''}` }]
    ]
  };
}

// Buttons shown alongside the token/welcome message: sign-up page, login
// page, and (if we know the user's referral link) a native Telegram share
// sheet button — no inline-mode setup required.
function startKeyboard(myReferralLink) {
  const rows = [
    [{ text: '📝 Sign Up', url: SITE_URL + '/register' }, { text: '🔑 Login', url: SITE_URL + '/login' }]
  ];
  if (myReferralLink) {
    const shareText = 'Host your Telegram bots 24/7 with VØĪD HØSTÏÑG — join with my referral link:';
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(myReferralLink)}&text=${encodeURIComponent(shareText)}`;
    rows.push([{ text: '📤 Share My Referral Link', url: shareUrl }]);
  }
  return { inline_keyboard: rows };
}

// ── Token issuance (shared by /start and the "I've Joined" button) ──────
async function issueTokenFor(fromUser, chatId, refPayload) {
  const userId = fromUser.id;
  const firstName = fromUser.first_name || 'there';
  const tgUsername = fromUser.username || null;

  const existing = (await db.get('SELECT * FROM activation_tokens WHERE telegram_id = ?', [String(userId)]));
  const myReferralLink = botUsername && tgUsername ? `https://t.me/${botUsername}?start=ref_${tgUsername}` : null;
  const referralBlock = myReferralLink
    ? `\n\n🔗 *Your referral link:*\n\`${myReferralLink}\`\n_Share it — every friend who signs up with it gives you +1 day of premium._`
    : '';

  if (existing) {
    const usedNote = existing.used_by
      ? '\n\n*Note:* This token was already used to create an account.'
      : '';
    return send(chatId,
      `👋 *Welcome back, ${firstName}!*\n\nYour activation token:\n\n\`${existing.token}\`\n\nPaste it on the VØĪD HØSTÏÑG sign-up page.${usedNote}${referralBlock}`,
      { reply_markup: startKeyboard(myReferralLink) }
    );
  }

  if (!tgUsername) {
    return send(chatId,
      `👋 *Welcome to VØĪD HØSTÏÑG, ${firstName}!*\n\n` +
      `You need a public Telegram @username to register.\n\n` +
      `Go to *Telegram Settings → Username*, set one, then send /start again.`
    );
  }

  let referredBy = null;
  if (refPayload && refPayload.startsWith('ref_')) {
    const refUsername = refPayload.slice(4).trim();
    if (refUsername && refUsername.toLowerCase() !== tgUsername.toLowerCase()) {
      const referrer = (await db.get('SELECT id FROM users WHERE username = ?', [refUsername]));
      if (referrer) referredBy = refUsername;
    }
  }

  const token = generateToken();
  (await db.run('INSERT INTO activation_tokens (token, telegram_id, telegram_username, referred_by) VALUES (?, ?, ?, ?)', [token, String(userId), tgUsername, referredBy]));

  const referralNote = referredBy ? `\n\n_Referred by @${referredBy} — they'll get +1 day once you finish signing up._` : '';

  return send(chatId,
    `👋 *Welcome to VØĪD HØSTÏÑG, ${firstName}!*\n\n` +
    `VØĪD HØSTÏÑG lets you host your Telegram bots 24/7 — no server required.\n\n` +
    `Your *Activation Token:*\n\n\`${token}\`\n\n` +
    `*How to use it:*\n` +
    `1. Go to the VØĪD HØSTÏÑG sign-up page\n` +
    `2. Enter your username, email and password\n` +
    `3. Paste this token in the *Activation Token* field\n` +
    `4. Tap *Create Account*\n\n` +
    `You get *7 days free* (up to 3 bots).${referralNote}\n\n` +
    `Keep this token safe — it can only be used once.${referralBlock}`,
    { reply_markup: startKeyboard(myReferralLink) }
  );
}

function init() {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    console.log('[Bot] No TELEGRAM_BOT_TOKEN set, skipping bot init');
    return;
  }

  try {
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, {
      polling: {
        interval: 3000,
        autoStart: false,
        params: { timeout: 10, limit: 100 }
      }
    });

    exports._botInstance = bot;

    bot.on('polling_error', (err) => {
      const code = err.code || '';
      if (['EFATAL', 'EPARSE', 'ETELEGRAM', 'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT'].includes(code)) {
        console.warn('[Bot] Polling error (non-fatal):', code, err.message?.slice(0, 80));
        return;
      }
      console.warn('[Bot] Polling error:', err.message?.slice(0, 80));
    });

    bot.on('error', (err) => {
      console.warn('[Bot] Error (suppressed):', err.message?.slice(0, 80));
    });

    // ── /start [ref_<username>] ───────────────────────────────────────
    bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
      const userId = msg.from.id;
      const refPayload = match && match[1] ? match[1].trim() : null;
      console.log('[Bot] /start received from', userId, refPayload ? `(ref: ${refPayload})` : '');

      try {
        // Already has a token — no need to gate on the channel again
        const existing = (await db.get('SELECT * FROM activation_tokens WHERE telegram_id = ?', [String(userId)]));
        if (existing) return await issueTokenFor(msg.from, userId, refPayload);

        const joined = await isChannelMember(userId);
        if (!joined) {
          return send(userId,
            `👋 *Welcome to VØĪD HØSTÏÑG!*\n\n` +
            `Before I can give you your Activation Token, please join our channel first:\n\n` +
            `${CHANNEL}\n\n` +
            `Once you've joined, tap *I've Joined* below.`,
            { reply_markup: joinChannelKeyboard(refPayload) }
          );
        }

        await issueTokenFor(msg.from, userId, refPayload);
      } catch (err) {
        console.error('[Bot] /start handler error:', err.message?.slice(0, 100));
      }
    });

    // ── "I've Joined" button ──────────────────────────────────────────
    bot.on('callback_query', async (q) => {
      if (!q.data || !q.data.startsWith('check_join')) return;
      const userId = q.from.id;
      const refPayload = q.data.split(':')[1] || null;

      try {
        const joined = await isChannelMember(userId);
        if (!joined) {
          await bot.answerCallbackQuery(q.id, { text: '❌ You have not joined the channel yet.', show_alert: true });
          return;
        }
        await bot.answerCallbackQuery(q.id, { text: '✅ Verified! Sending your token...' });
        await issueTokenFor(q.from, q.message.chat.id, refPayload);
      } catch (err) {
        console.error('[Bot] callback_query handler error:', err.message?.slice(0, 100));
      }
    });

    // Start polling AFTER handlers are registered
    bot.startPolling();
    bot.getMe().then(me => { botUsername = me.username; }).catch(() => {});
    console.log('[Bot] Telegram token bot started');

  } catch (err) {
    console.error('[Bot] Failed to init bot:', err.message);
  }
}

function notifyUserCrash(bot_info) {
  if (!bot_info || !bot_info.telegram_id || !exports._botInstance) return;
  try {
    exports._botInstance.sendMessage(bot_info.telegram_id,
      `Your bot *"${bot_info.name}"* has crashed and been stopped automatically.\n\nCheck your bot code and restart it from your dashboard.`,
      { parse_mode: 'Markdown' }
    ).catch(() => {});
  } catch {}
}

// ── Account-lifecycle notifications ──────────────────────────────────────
async function notifyPlanExpired(user) {
  const tid = await getTelegramId(user.id);
  send(tid, `⏰ *Your VØĪD HØSTÏÑG premium plan has expired.*\n\nYour account has been moved back to the *Free* plan. Renew anytime to get your extra bots and storage back.`);
}

async function notifyPlanGranted(user, label, expiresAtIso) {
  const tid = await getTelegramId(user.id);
  const expiresStr = expiresAtIso ? new Date(expiresAtIso).toLocaleString() : 'no expiry (lifetime)';
  send(tid, `🎉 *Your plan was upgraded!*\n\nPlan: *${label}*\nExpires: ${expiresStr}\n\nEnjoy your new limits!`);
}

async function notifyPlanRemoved(user) {
  const tid = await getTelegramId(user.id);
  send(tid, `ℹ️ *Your premium plan was removed by an admin.*\n\nYou're now on the *Free* plan.`);
}

async function notifyBanned(user, reason) {
  const tid = await getTelegramId(user.id);
  send(tid, `🚫 *Your VØĪD HØSTÏÑG account has been banned.*${reason ? `\n\nReason: _${reason}_` : ''}\n\nContact support if you believe this is a mistake.`);
}

async function notifyUnbanned(user) {
  const tid = await getTelegramId(user.id);
  send(tid, `✅ *Your VØĪD HØSTÏÑG account has been unbanned.*\n\nYou can log back in now.`);
}

async function notifyReferralCredit(referrerUser, referredInfo, days, newExpiryIso) {
  const tid = await getTelegramId(referrerUser.id);
  const r = referredInfo || {};
  const tgLine = r.telegram_username
    ? `@${r.telegram_username} (Telegram ID: \`${r.telegram_id || '—'}\`)`
    : (r.telegram_id ? `Telegram ID: \`${r.telegram_id}\`` : 'Telegram: —');
  send(tid,
    `🎁 *Referral bonus!*\n\n` +
    `Someone just signed up using your referral link:\n\n` +
    `• *Account:* @${r.username || 'unknown'} (User ID: \`${r.userId ?? '—'}\`)\n` +
    `• *Telegram:* ${tgLine}\n` +
    `• *Joined:* ${r.joinedAt ? new Date(r.joinedAt).toLocaleString() : new Date().toLocaleString()}\n\n` +
    `*+${days} day(s)* added to your premium.\n` +
    `New expiry: ${new Date(newExpiryIso).toLocaleString()}`
  );
}

module.exports = {
  init,
  notifyUserCrash,
  notifyPlanExpired,
  notifyPlanGranted,
  notifyPlanRemoved,
  notifyBanned,
  notifyUnbanned,
  notifyReferralCredit,
  getTelegramId
};
