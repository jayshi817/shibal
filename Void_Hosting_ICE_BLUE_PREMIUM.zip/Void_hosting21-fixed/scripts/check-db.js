// Smoke test: confirms DATABASE_URL works, the schema applies, and the core tables exist.
//   DATABASE_URL=postgres://... node scripts/check-db.js
require('dotenv').config();
const db = require('../database');

const REQUIRED = ['users', 'bots', 'logs', 'activation_tokens', 'proxies', 'bot_env_vars',
  'referrals', 'billing_history', 'announcements', 'login_attempts'];

(async () => {
  try {
    await db.init();
    const rows = await db.all("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    const have = new Set(rows.map(r => r.table_name));
    const missing = REQUIRED.filter(t => !have.has(t));
    if (missing.length) throw new Error('Missing tables: ' + missing.join(', '));
    const { c } = await db.get('SELECT COUNT(*) AS c FROM users');
    console.log(`OK: connected, schema applied, ${have.size} tables, ${c} user(s).`);
  } catch (err) {
    console.error('FAILED:', err.message);
    process.exitCode = 1;
  } finally {
    await db.pool.end();
  }
})();
