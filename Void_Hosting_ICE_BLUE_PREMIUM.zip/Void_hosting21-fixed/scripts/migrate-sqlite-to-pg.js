// One-time migration: copies data from the old SQLite file into PostgreSQL.
//
//   npm i better-sqlite3 --no-save          # only needed for this script
//   DATABASE_URL=postgres://... SQLITE_PATH=/data/database.sqlite \
//     node scripts/migrate-sqlite-to-pg.js
//
// Run it once, against an EMPTY Postgres database, with the app stopped.
require('dotenv').config();
const path = require('path');
const Database = require('better-sqlite3');
const { Pool } = require('pg');
const fs = require('fs');

const SQLITE_PATH = process.env.SQLITE_PATH || process.env.DB_PATH || '/data/database.sqlite';
// Parents before children so foreign keys are satisfied.
const TABLES = ['users', 'activation_tokens', 'bots', 'bot_env_vars', 'logs', 'proxies',
  'proxy_requests', 'ban_history', 'billing_history', 'referrals', 'announcements',
  'login_attempts', 'ddos_logs', 'email_codes'];
const BATCH = 500;

// SQLite stores DATETIME as "YYYY-MM-DD HH:MM:SS" in UTC with no zone marker.
const SQLITE_TS = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(\.\d+)?$/;
const toValue = (v) => (typeof v === 'string' && SQLITE_TS.test(v) ? v.replace(' ', 'T') + 'Z' : v);

(async () => {
  if (!fs.existsSync(SQLITE_PATH)) throw new Error(`SQLite file not found: ${SQLITE_PATH}`);
  const sqlite = new Database(SQLITE_PATH, { readonly: true });
  const pg = new Pool({ connectionString: process.env.DATABASE_URL,
    ssl: /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL || '') ? false : { rejectUnauthorized: false } });

  await pg.query(fs.readFileSync(path.join(__dirname, '..', 'schema.sql'), 'utf8'));
  const client = await pg.connect();
  try {
    await client.query('BEGIN');
    for (const table of TABLES) {
      const hasTable = sqlite.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(table);
      if (!hasTable) { console.log(`- ${table}: not in SQLite, skipped`); continue; }

      const pgCols = (await client.query(
        "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=$1", [table]
      )).rows.map(r => r.column_name);
      const sqliteCols = sqlite.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);
      const cols = sqliteCols.filter(c => pgCols.includes(c));
      const rows = sqlite.prepare(`SELECT ${cols.join(', ')} FROM ${table}`).all();

      await client.query(`DELETE FROM ${table}`);
      for (let i = 0; i < rows.length; i += BATCH) {
        const chunk = rows.slice(i, i + BATCH);
        const params = [];
        const tuples = chunk.map(r => {
          const ph = cols.map(c => { params.push(toValue(r[c])); return `$${params.length}`; });
          return `(${ph.join(', ')})`;
        });
        await client.query(`INSERT INTO ${table} (${cols.join(', ')}) VALUES ${tuples.join(', ')}`, params);
      }

      // Keep SERIAL sequences ahead of the copied ids so new rows don't collide.
      if (cols.includes('id') && pgCols.includes('id')) {
        await client.query(
          `SELECT setval(pg_get_serial_sequence('${table}', 'id'), COALESCE(MAX(id), 1), MAX(id) IS NOT NULL) FROM ${table}`
        ).catch(() => {}); // TEXT primary keys (bots) have no sequence
      }
      console.log(`- ${table}: ${rows.length} row(s) copied`);
    }
    await client.query('COMMIT');
    console.log('Migration complete.');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Migration failed, nothing was written:', err.message);
    process.exitCode = 1;
  } finally {
    client.release();
    await pg.end();
    sqlite.close();
  }
})();
