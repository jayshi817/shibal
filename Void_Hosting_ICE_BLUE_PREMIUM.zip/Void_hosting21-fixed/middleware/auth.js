const db = require('../database');
const { asyncHandler } = require('../utils/asyncHandler');

// Rejects requests without a session, and destroys sessions of banned/deleted users.
const requireAuth = asyncHandler(async (req, res, next) => {
  if (req.session && req.session.userId) {
    const user = await db.get('SELECT banned FROM users WHERE id = ?', [req.session.userId]);
    if (!user) {
      return req.session.destroy(() => res.redirect('/login'));
    }
    if (user.banned) {
      return req.session.destroy(() => res.redirect('/login?banned=1'));
    }
    return next();
  }
  res.redirect('/login');
});

function requireGuest(req, res, next) {
  if (req.session && req.session.userId) {
    return res.redirect('/dashboard');
  }
  next();
}

// Same admin check used in server.js: user id 1, or username matches
// ADMIN_USERNAME — kept in one place so the API and the page routes never
// disagree about who counts as an admin.
function isAdminUser(user) {
  if (!user) return false;
  return user.id === 1 || user.username === (process.env.ADMIN_USERNAME || 'admin');
}

const requireAdmin = asyncHandler(async (req, res, next) => {
  if (!req.session || !req.session.userId) return res.redirect('/login');
  const user = await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]);
  if (!isAdminUser(user)) return res.status(403).json({ success: false, message: 'Admin access only' });
  req.adminUser = user;
  next();
});

module.exports = { requireAuth, requireGuest, requireAdmin, isAdminUser };
