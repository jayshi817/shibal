// Cloudflare middleware — stripped down to a no-op since Cloudflare is not
// in use. Keeps the same exports so nothing else needs to change.

function cloudflareMiddleware(req, res, next) {
  req.realIP = req.ip;
  req.cfMeta = {};
  next();
}

function getRecentAttacks() { return []; }
function getTopAttackers() { return []; }

module.exports = { cloudflareMiddleware, getRecentAttacks, getTopAttackers };
