const { asyncHandler } = require('./utils/asyncHandler');
require('dotenv').config();
const express = require('express');
const fs = require('fs');
// Ensure persistent data directories exist
const DATA_DIR = process.env.DATA_DIR || '/data';
['uploads', 'extracted'].forEach(sub => {
  fs.mkdirSync(require('path').join(DATA_DIR, sub), { recursive: true });
});
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const db = require('./database');
const authRoutes = require('./routes/auth');
const botRoutes = require('./routes/bots');
const fileRoutes = require('./routes/files');
const adminRoutes = require('./routes/admin');
const monitorRoutes = require('./routes/monitor');
const proxyRoutes = require('./routes/proxies');
const announcementRoutes = require('./routes/announcements');
const envVarRoutes = require('./routes/envvars');
const { requireAuth, requireGuest, isAdminUser } = require('./middleware/auth');
const { cloudflareMiddleware, getRecentAttacks, getTopAttackers } = require('./middleware/cloudflare');
const telegramBot = require('./bot/telegram');

const app = express();
const PORT = process.env.PORT || 3000;

// Trust Cloudflare proxy
app.set('trust proxy', 1);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Cloudflare DDoS protection (apply to all routes)
app.use(cloudflareMiddleware);

app.use(session({
  secret: process.env.SESSION_SECRET || 'nixz-super-secret-key-change-in-prod',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300, keyGenerator: (req) => req.realIP || req.ip });
// Admin monitor polls every couple of seconds, so it skips the general limiter.
// It is still admin-only (requireAdmin on every route in routes/monitor.js).
app.use('/api', (req, res, next) => req.path.startsWith('/admin/monitor') ? next() : apiLimiter(req, res, next));

app.use('/api/auth', authRoutes);
app.use('/api/bots', botRoutes);
app.use('/api/bots/:id/files', fileRoutes);
app.use('/api/admin/monitor', monitorRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/proxies', proxyRoutes);
app.use('/api/announcements', announcementRoutes);
app.use('/api/bots/:id/env', envVarRoutes);

// ── Admin account bootstrap ──────────────────────────────────────
// Reads ADMIN_USERNAME / ADMIN_PASSWORD from environment variables (set
// these in Railway → Variables — NEVER commit real credentials into code
// that goes to a public GitHub repo) and makes sure that account exists
// with admin rights. Runs on every boot; re-syncs the password if you
// change the env var, so the account always matches what's configured.
async function ensureAdminAccount() {
  const username = process.env.ADMIN_USERNAME;
  const plainPassword = process.env.ADMIN_PASSWORD;
  if (!username || !plainPassword) {
    console.log('[VØĪD HØSTÏÑG] ADMIN_USERNAME / ADMIN_PASSWORD not set in env — skipping admin bootstrap.');
    return;
  }
  const bcrypt = require('bcryptjs');
  const hashed = bcrypt.hashSync(plainPassword, 12);
  const existing = (await db.get('SELECT * FROM users WHERE username = ?', [username]));
  if (existing) {
    (await db.run('UPDATE users SET password = ?, email_verified = 1 WHERE id = ?', [hashed, existing.id]));
    console.log(`[VØĪD HØSTÏÑG] Admin account "${username}" verified (password synced from env).`);
  } else {
    (await db.run('INSERT INTO users (username, email, password, plan, email_verified) VALUES (?, ?, ?, ?, 1)', [username, `${username.toLowerCase()}@void.local`, hashed, 'premium']));
    console.log(`[VØĪD HØSTÏÑG] Admin account "${username}" created.`);
  }
}

// ── Security dashboard (admin only) ───────────────────────────
app.get('/api/security/attacks', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  if (!isAdminUser(user)) {
    return res.json({ success: false, message: 'Admin access only. Contact support if you think this is an error.' });
  }
  const attacks = getRecentAttacks(100);
  const topAttackers = getTopAttackers(20);
  res.json({ success: true, attacks, topAttackers });
}));

app.get('/api/security/ip', (req, res) => {
  // Returns caller's detected IP (useful for debugging Cloudflare setup)
  res.json({
    realIP: req.realIP,
    cfMeta: req.cfMeta,
    raw: req.socket.remoteAddress
  });
});

// ── Pages ──────────────────────────────────────────────────────
app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get('/login', requireGuest, (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));
app.get('/register', requireGuest, (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));
app.get('/dashboard', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/admin/monitor', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  if (!isAdminUser(user)) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'monitor.html'));
}));

app.get('/admin', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  if (!isAdminUser(user)) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
}));
app.get('/bot/create', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'create-bot.html')));
app.get('/bot/view/:id', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'bot.html')));
app.get('/bot/edit/:id', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'bot.html')));
app.get('/pricing', (req, res) => res.sendFile(path.join(__dirname, 'public', 'pricing.html')));
app.get('/verify-email', requireGuest, (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));
app.get('/forgot-password', requireGuest, (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));
app.get('/reset-password', requireGuest, (req, res) => res.sendFile(path.join(__dirname, 'public', 'auth.html')));
app.get('/status', (req, res) => res.sendFile(path.join(__dirname, 'public', 'status.html')));

// Public status API — shows bot names + status only (no tokens/IDs)
app.get('/api/status', asyncHandler(async (req, res) => {
  const bots = (await db.all("SELECT name, status, uptime_start FROM bots ORDER BY name", []));
  res.json({ success: true, bots });
}));
app.get('/security', requireAuth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'security.html')));

// Public token check — used by the signup form to validate before submitting
app.get('/api/auth/check-token', asyncHandler(async (req, res) => {
  const token = String(req.query.token || '').trim().toUpperCase();
  if (!token) return res.json({ valid: false, message: 'No token provided' });
  const row = (await db.get('SELECT used_by FROM activation_tokens WHERE token = ?', [token]));
  if (!row) return res.json({ valid: false, message: 'Token not found' });
  if (row.used_by) return res.json({ valid: false, message: 'Token already used' });
  return res.json({ valid: true, message: 'Token is valid ✓' });
}));

app.get('/api/admin/stats', requireAuth, asyncHandler(async (req, res) => {
  const user = (await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]));
  const { isAdminUser } = require('./middleware/auth');
  if (!isAdminUser(user)) return res.json({ success: false, message: 'Admin only' });
  const totalUsers = (await db.get("SELECT COUNT(*) as c FROM users", [])).c;
  const premiumUsers = (await db.get("SELECT COUNT(*) as c FROM users WHERE plan = 'premium'", [])).c;
  const bannedUsers = (await db.get("SELECT COUNT(*) as c FROM users WHERE banned = 1", [])).c;
  const totalBots = (await db.get("SELECT COUNT(*) as c FROM bots", [])).c;
  const runningBots = (await db.get("SELECT COUNT(*) as c FROM bots WHERE status = 'running'", [])).c;
  const newUsersToday = (await db.get("SELECT COUNT(*) as c FROM users WHERE created_at >= CURRENT_DATE", [])).c;
  const newUsersWeek = (await db.get("SELECT COUNT(*) as c FROM users WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'", [])).c;
  res.json({ success: true, stats: { totalUsers, premiumUsers, bannedUsers, totalBots, runningBots, newUsersToday, newUsersWeek } });
}));

app.get('/api/me', requireAuth, asyncHandler(async (req, res) => {
  await db.syncExpiredPlans();
  const user = (await db.get('SELECT id, username, email, plan, created_at, trial_started_at, premium_expires_at FROM users WHERE id = ?', [req.session.userId]));
  let trialDaysLeft = null;
  if (user && user.plan === 'free') {
    const start = user.trial_started_at ? new Date(user.trial_started_at).getTime() : new Date(user.created_at).getTime();
    const msLeft = (start + 7 * 24 * 60 * 60 * 1000) - Date.now();
    trialDaysLeft = Math.max(0, Math.ceil(msLeft / (24 * 60 * 60 * 1000)));
  }
  res.json({ success: true, user: { ...user, is_admin: isAdminUser(user), trial_days_left: trialDaysLeft } });
}));

app.get('/api/me/billing', requireAuth, asyncHandler(async (req, res) => {
  const rows = (await db.all('SELECT * FROM billing_history WHERE user_id = ? ORDER BY created_at DESC', [req.session.userId]));
  res.json({ success: true, history: rows });
}));

// ── Error handler: API errors come back as JSON, like the rest of the app ──
app.use((err, req, res, next) => {
  console.error('[VØĪD HØSTÏÑG] Unhandled error:', err && err.message);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ success: false, message: err.message || 'Server error' });
});

process.on('unhandledRejection', (err) => console.error('[VØĪD HØSTÏÑG] Unhandled rejection:', err && err.message));

// Schema first, then the admin account, then accept traffic.
async function start() {
  await db.init();
  await ensureAdminAccount();
  app.listen(PORT, async () => {
  console.log(`[VØĪD HØSTÏÑG] Server running on port ${PORT}`);
  await telegramBot.init();
  setInterval(async () => {
    // Grab anyone about to be flipped to Free BEFORE syncing, so we can notify them
    try {
      const justExpired = (await db.all(`
        SELECT * FROM users
        WHERE plan = 'premium' AND premium_expires_at IS NOT NULL AND premium_expires_at <= CURRENT_TIMESTAMP
      `, []));
      await db.syncExpiredPlans();
      justExpired.forEach(async u => { try { await telegramBot.notifyPlanExpired(u); } catch {} });
    } catch {
      await db.syncExpiredPlans();
    }
    // Send expiry warning emails 3 days before plan ends
    try {
      const { sendMail, planExpiryEmail } = require('./services/mailer');
      const expiringSoon = (await db.all(`
        SELECT u.username, u.email, u.plan, u.premium_expires_at, u.email_verified
        FROM users u
        WHERE u.plan = 'premium'
          AND u.email IS NOT NULL AND u.email_verified = 1
          AND u.premium_expires_at IS NOT NULL
          AND u.premium_expires_at <= NOW() + INTERVAL '3 days'
          AND u.premium_expires_at > NOW()
      `, []));
      expiringSoon.forEach(u => {
        const expiresAt = new Date(u.premium_expires_at).toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' });
        sendMail({ to: u.email, subject: 'Your VØĪD HØSTÏÑG plan is expiring soon', html: planExpiryEmail({ username: u.username, plan: u.plan, expiresAt }) });
      });
    } catch {}
  }, 5 * 60 * 1000);
});
}

start().catch((err) => {
  console.error('[VØĪD HØSTÏÑG] Startup failed:', err);
  process.exit(1);
});
