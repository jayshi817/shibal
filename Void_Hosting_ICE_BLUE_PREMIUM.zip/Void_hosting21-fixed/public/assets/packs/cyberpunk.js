/* Cyberpunk Neon City — animated scene for the "cyberpunk" pack.
   Constellation dots, falling rain, neon buildings with lit windows, floating
   tech keywords, and a bot that flies across the sky. Respects reduced motion. */
(function () {
  'use strict';

  var NEON  = ['#ff2bd6', '#00f0ff', '#ffe14d', '#39ff88', '#8b5cf6'];
  var WORDS = ['bot.py', 'async', 'webhook', 'deploy', 'uptime', '/start', 'JSON', 'polling',
               'token', 'cron', 'SSL', 'API', 'logs', 'restart', 'node', 'pip', 'env', 'telegram'];
  var SIGNS = ['VOID', 'BOT', '24/7', 'HOST', 'ON', 'RUN'];
  var reduceMotion = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  var canvas = null, ctx = null, W = 0, H = 0, DPR = 1;
  var running = false, raf = 0, last = 0, t = 0, nextVehicle = 0;
  var stars = [], rain = [], words = [], layers = [], vehicles = [];

  function rnd(a, b) { return a + Math.random() * (b - a); }
  function pick(arr) { return arr[(Math.random() * arr.length) | 0]; }

  // ---------- buildings (3 parallax layers) ----------
  function makeLayer(cfg) {
    var blds = [], x = 0, target = W * 2 + 240;
    while (x < target) {
      var w = rnd(cfg.minW, cfg.maxW);
      var h = H * rnd(cfg.minH, cfg.maxH);
      var cols = Math.max(2, Math.floor((w - 12) / 11));
      var rows = Math.max(3, Math.floor((h - 20) / 14));
      var windows = [];
      for (var i = 0; i < cols * rows; i++) windows.push(Math.random() < 0.38 ? 1 : 0);
      blds.push({
        x: x, w: w, h: h, cols: cols, rows: rows, windows: windows,
        color: pick(NEON), phase: rnd(0, 6.28),
        sign: Math.random() < 0.22 ? { text: pick(SIGNS), color: pick(NEON) } : null
      });
      x += w + rnd(4, 18);
    }
    return { blds: blds, total: x, offset: 0, speed: cfg.speed, alpha: cfg.alpha, dark: cfg.dark };
  }

  function drawBuilding(b, x, y, L) {
    ctx.fillStyle = L.dark;
    ctx.fillRect(x, y, b.w, H - y + 2);

    ctx.save();
    ctx.shadowColor = b.color;
    ctx.shadowBlur = 12;
    ctx.strokeStyle = b.color;
    ctx.lineWidth = 1.2;
    ctx.strokeRect(x + 0.5, y + 0.5, b.w, H - y);
    ctx.restore();

    for (var r = 0; r < b.rows; r++) {
      for (var c = 0; c < b.cols; c++) {
        if (!b.windows[r * b.cols + c]) continue;
        ctx.fillStyle = b.color;
        ctx.globalAlpha = L.alpha * (0.5 + 0.35 * Math.sin(t * 1.7 + b.phase + r));
        ctx.fillRect(x + 6 + c * 11, y + 10 + r * 14, 5, 6);
      }
    }
    ctx.globalAlpha = L.alpha;

    if (b.sign) {
      var text = b.sign.text;
      ctx.save();
      ctx.font = 'bold 12px ui-monospace, monospace';
      ctx.fillStyle = b.sign.color;
      ctx.shadowColor = b.sign.color;
      ctx.shadowBlur = 16;
      ctx.globalAlpha = L.alpha * (0.6 + 0.4 * Math.sin(t * 2.4 + b.phase));
      ctx.textAlign = 'center';
      for (var k = 0; k < text.length; k++) {
        ctx.fillText(text[k], x + b.w / 2, y + 22 + k * 14);
      }
      ctx.restore();
    }
  }

  function drawLayer(L, dt) {
    L.offset = (L.offset + L.speed * dt) % L.total;
    ctx.save();
    ctx.globalAlpha = L.alpha;
    for (var pass = 0; pass < 2; pass++) {
      var base = pass * L.total - L.offset;
      for (var i = 0; i < L.blds.length; i++) {
        var b = L.blds[i];
        var x = b.x + base;
        if (x + b.w < -10 || x > W + 10) continue;
        drawBuilding(b, x, H * 0.92 - b.h, L);
      }
    }
    ctx.restore();
  }

  // ---------- sky, floor grid, constellation ----------
  function drawSky() {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#05010d');
    g.addColorStop(0.55, '#1a0633');
    g.addColorStop(0.82, '#3a0a4c');
    g.addColorStop(1, '#07030f');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    var rg = ctx.createRadialGradient(W * 0.5, H * 0.82, 10, W * 0.5, H * 0.82, Math.max(W, H) * 0.6);
    rg.addColorStop(0, 'rgba(255,43,214,0.35)');
    rg.addColorStop(1, 'rgba(255,43,214,0)');
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
  }

  function drawFloorGrid() {
    var horizon = H * 0.92;
    ctx.save();
    ctx.strokeStyle = 'rgba(0,240,255,0.22)';
    ctx.lineWidth = 1;
    for (var i = 1; i <= 8; i++) {
      var y = horizon + Math.pow(i / 8, 2) * (H - horizon);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    for (var j = -10; j <= 10; j++) {
      ctx.beginPath();
      ctx.moveTo(W / 2, horizon);
      ctx.lineTo(W / 2 + j * (W / 6), H);
      ctx.stroke();
    }
    ctx.restore();
  }

  function updateStars(dt) {
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      s.x += s.vx * dt; s.y += s.vy * dt;
      if (s.x < -10) s.x = W + 10; if (s.x > W + 10) s.x = -10;
      if (s.y < -10) s.y = H * 0.7; if (s.y > H * 0.7) s.y = -10;
    }
  }
  function drawStars() {
    ctx.save();
    ctx.fillStyle = 'rgba(0,240,255,0.85)';
    for (var i = 0; i < stars.length; i++) {
      ctx.beginPath(); ctx.arc(stars[i].x, stars[i].y, stars[i].r, 0, 6.283); ctx.fill();
    }
    ctx.lineWidth = 0.6;
    for (var a = 0; a < stars.length; a++) {
      for (var b = a + 1; b < stars.length; b++) {
        var dx = stars[a].x - stars[b].x, dy = stars[a].y - stars[b].y;
        var d = Math.sqrt(dx * dx + dy * dy);
        if (d < 110) {
          ctx.strokeStyle = 'rgba(0,240,255,' + ((1 - d / 110) * 0.22).toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(stars[a].x, stars[a].y); ctx.lineTo(stars[b].x, stars[b].y); ctx.stroke();
        }
      }
    }
    ctx.restore();
  }

  // ---------- rain ----------
  function updateRain(dt) {
    for (var i = 0; i < rain.length; i++) {
      var r = rain[i];
      r.y += r.speed * dt; r.x -= r.speed * dt * 0.25;
      if (r.y > H + 20) { r.y = -rnd(0, H * 0.3); r.x = rnd(0, W + 80); }
    }
  }
  function drawRain() {
    ctx.save();
    ctx.lineWidth = 1;
    for (var i = 0; i < rain.length; i++) {
      var r = rain[i];
      var g = ctx.createLinearGradient(r.x, r.y, r.x + r.len * 0.25, r.y - r.len);
      g.addColorStop(0, 'rgba(160,220,255,0)');
      g.addColorStop(1, 'rgba(160,220,255,' + r.a + ')');
      ctx.strokeStyle = g;
      ctx.beginPath(); ctx.moveTo(r.x, r.y); ctx.lineTo(r.x + r.len * 0.25, r.y - r.len); ctx.stroke();
    }
    ctx.restore();
  }

  // ---------- floating tech keywords ----------
  function updateWords(dt) {
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      w.y -= w.vy * dt;
      if (w.y < -30) { w.y = H + rnd(0, 60); w.x = rnd(0, W); }
    }
  }
  function drawWords() {
    ctx.save();
    ctx.font = '12px ui-monospace, monospace';
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      ctx.globalAlpha = w.a * (0.55 + 0.45 * Math.sin(t * 1.3 + w.ph));
      ctx.fillStyle = w.color;
      ctx.shadowColor = w.color;
      ctx.shadowBlur = 8;
      ctx.fillText(w.text, w.x, w.y);
    }
    ctx.restore();
  }

  // ---------- flying bot ----------
  function rr(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function updateVehicles(dt) {
    if (t >= nextVehicle) {
      vehicles.push({ x: -90, y: H * rnd(0.12, 0.42), speed: rnd(90, 150), bob: rnd(0, 6.28), trail: [], tick: 0 });
      nextVehicle = t + rnd(7, 12);
    }
    for (var i = vehicles.length - 1; i >= 0; i--) {
      var v = vehicles[i];
      v.x += v.speed * dt;
      v.tick += dt;
      if (v.tick > 0.035) {
        v.tick = 0;
        v.trail.push({ x: v.x - 30, y: v.y + Math.sin(t * 2.2 + v.bob) * 6 + rnd(-2, 2), a: 0.8 });
      }
      for (var k = 0; k < v.trail.length; k++) v.trail[k].a -= dt * 0.9;
      v.trail = v.trail.filter(function (p) { return p.a > 0; });
      if (v.x > W + 120) vehicles.splice(i, 1);
    }
  }
  function drawVehicles() {
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      var y = v.y + Math.sin(t * 2.2 + v.bob) * 6;

      for (var k = 0; k < v.trail.length; k++) {
        ctx.fillStyle = 'rgba(255,43,214,' + Math.max(0, v.trail[k].a * 0.7).toFixed(3) + ')';
        ctx.fillRect(v.trail[k].x, v.trail[k].y, 3, 2);
      }

      ctx.save();
      ctx.translate(v.x, y);

      var flame = 12 + Math.random() * 7;
      var g = ctx.createLinearGradient(-6, 0, -6 - flame, 0);
      g.addColorStop(0, 'rgba(255,43,214,0.95)');
      g.addColorStop(1, 'rgba(255,43,214,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(-6, -4); ctx.lineTo(-6 - flame, 0); ctx.lineTo(-6, 4); ctx.closePath(); ctx.fill();

      ctx.shadowColor = '#00f0ff'; ctx.shadowBlur = 16;
      ctx.fillStyle = '#0b1030'; ctx.strokeStyle = '#00f0ff'; ctx.lineWidth = 1.5;
      rr(0, -12, 46, 24, 8); ctx.fill(); ctx.stroke();

      ctx.shadowColor = '#ff2bd6';
      ctx.fillStyle = '#ff2bd6';
      rr(8, -6, 22, 10, 4); ctx.fill();

      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(16, -1, 2, 0, 6.283); ctx.fill();
      ctx.beginPath(); ctx.arc(24, -1, 2, 0, 6.283); ctx.fill();

      ctx.strokeStyle = '#ffe14d'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(23, -12); ctx.lineTo(23, -19); ctx.stroke();
      ctx.fillStyle = '#ffe14d';
      ctx.beginPath(); ctx.arc(23, -20, 2.2, 0, 6.283); ctx.fill();

      ctx.restore();
    }
  }

  // ---------- frame ----------
  function render(dt) {
    drawSky();
    drawStars();
    drawLayer(layers[0], dt);
    drawLayer(layers[1], dt);
    drawRain();
    drawLayer(layers[2], dt);
    drawFloorGrid();
    drawWords();
    drawVehicles();
  }

  function update(dt) {
    updateStars(dt);
    updateRain(dt);
    updateWords(dt);
    updateVehicles(dt);
  }

  function frame(ts) {
    if (!running) return;
    var dt = Math.min(0.05, (ts - last) / 1000 || 0);
    last = ts;
    t += dt;
    update(dt);
    ctx.clearRect(0, 0, W, H);
    render(dt);
    raf = requestAnimationFrame(frame);
  }

  function build() {
    stars = [];
    var n = Math.max(40, Math.round((W * H) / 16000));
    for (var i = 0; i < n; i++) {
      stars.push({ x: rnd(0, W), y: rnd(0, H * 0.7), vx: rnd(-6, 6), vy: rnd(-4, 4), r: rnd(0.6, 1.8) });
    }
    rain = [];
    for (var j = 0; j < 170; j++) {
      rain.push({ x: rnd(0, W + 80), y: rnd(-H, H), speed: rnd(420, 720), len: rnd(14, 30), a: rnd(0.18, 0.45) });
    }
    words = [];
    for (var k = 0; k < 16; k++) {
      words.push({ text: pick(WORDS), x: rnd(0, W), y: rnd(0, H), vy: rnd(10, 26), a: rnd(0.35, 0.8), ph: rnd(0, 6.28), color: pick(NEON) });
    }
    layers = [
      makeLayer({ minW: 26, maxW: 56, minH: 0.18, maxH: 0.42, speed: 6,  alpha: 0.35, dark: '#120524' }),
      makeLayer({ minW: 34, maxW: 72, minH: 0.26, maxH: 0.55, speed: 16, alpha: 0.6,  dark: '#0c0318' }),
      makeLayer({ minW: 48, maxW: 110, minH: 0.34, maxH: 0.72, speed: 34, alpha: 1,   dark: '#08020f' })
    ];
    vehicles = [];
    nextVehicle = t + 2;
  }

  function resize() {
    if (!canvas) return;
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = Math.round(W * DPR);
    canvas.height = Math.round(H * DPR);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    build();
    if (reduceMotion) { ctx.clearRect(0, 0, W, H); render(0); }
  }

  function start() {
    if (running) return;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'void-pack-scene';
      canvas.setAttribute('aria-hidden', 'true');
      canvas.style.cssText = 'position:fixed;left:0;top:0;z-index:-1;pointer-events:none;';
      document.body.insertBefore(canvas, document.body.firstChild);
      ctx = canvas.getContext('2d');
      window.addEventListener('resize', resize);
    }
    resize();
    running = true;
    last = performance.now();
    if (!reduceMotion) raf = requestAnimationFrame(frame);
  }

  function stop() {
    running = false;
    cancelAnimationFrame(raf);
    window.removeEventListener('resize', resize);
    if (canvas) { canvas.remove(); canvas = null; ctx = null; }
  }

  window.VoidPacks = window.VoidPacks || {};
  window.VoidPacks.cyberpunk = { start: start, stop: stop };
})();
