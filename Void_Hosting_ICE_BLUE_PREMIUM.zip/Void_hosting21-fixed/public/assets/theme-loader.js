/* VØĪD HØSTÏÑG — theme loader.
   Add a theme by putting its files in /assets/packs/ and adding one line to PACKS.
   Each pack may have a CSS file and a JS file. The JS registers
   window.VoidPacks[name] = { start(), stop() } and the loader calls start()/stop(). */
(function () {
  'use strict';

  var PACKS = {
    void: { label: 'VØID', css: '/assets/packs/void.css', js: null },
    nova: { label: 'Nova', css: '/assets/packs/nova.css', js: null }
  };
  var DEFAULT_PACK = 'void';   // the pack shown when the visitor has not chosen one
  var COOKIE = 'void_pack';

  var current = null;

  function getCookie(name) {
    var m = document.cookie.match('(?:^|; )' + name + '=([^;]*)');
    return m ? decodeURIComponent(m[1]) : null;
  }
  function setCookie(name, value) {
    document.cookie = name + '=' + encodeURIComponent(value) + '; path=/; max-age=31536000; SameSite=Lax';
  }
  function loadFonts() {
    if (document.getElementById('void-pack-fonts')) return;
    var l = document.createElement('link');
    l.id = 'void-pack-fonts';
    l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Orbitron:wght@600;800&family=Rajdhani:wght@400;600;700&family=Share+Tech+Mono&display=swap';
    document.head.appendChild(l);
  }
  function stopPack(name) {
    var css = document.getElementById('void-pack-css');
    if (css) css.remove();
    var api = window.VoidPacks && window.VoidPacks[name];
    if (api && api.stop) api.stop();
  }
  function startPack(name) {
    var api = window.VoidPacks && window.VoidPacks[name];
    if (api && api.start) api.start();
  }

  function apply(name) {
    if (!PACKS[name]) name = DEFAULT_PACK;
    if (current) stopPack(current);
    document.documentElement.setAttribute('data-pack', name);

    var p = PACKS[name];
    if (p.css) {
      loadFonts();
      var css = document.createElement('link');
      css.id = 'void-pack-css';
      css.rel = 'stylesheet';
      css.href = p.css;
      document.head.appendChild(css);
    }
    if (p.js) {
      if (window.VoidPacks && window.VoidPacks[name]) {
        startPack(name);                       // script already loaded earlier
      } else {
        var s = document.createElement('script');
        s.src = p.js;
        s.onload = function () { startPack(name); };
        document.body.appendChild(s);
      }
    }
    current = name;
    setCookie(COOKIE, name);
    renderSwitch();
  }

  function renderSwitch() { /* theme switcher removed: Nova only */ }

  function init() {
    var saved = getCookie(COOKIE);
    apply(PACKS[saved] ? saved : DEFAULT_PACK);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  window.VoidTheme = { set: apply, current: function () { return current; }, packs: PACKS };
})();
