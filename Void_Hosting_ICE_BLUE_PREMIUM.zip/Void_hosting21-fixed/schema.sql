-- PostgreSQL schema. Idempotent: safe to run on every startup.
-- Flags stay INTEGER (0/1) so existing `banned = 1` style checks keep working.

CREATE TABLE IF NOT EXISTS users (
  id                  SERIAL PRIMARY KEY,
  username            TEXT UNIQUE NOT NULL,
  email               TEXT UNIQUE,
  password            TEXT NOT NULL,
  plan                TEXT DEFAULT 'free',
  telegram_id         TEXT,
  email_verified      INTEGER DEFAULT 0,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  trial_started_at    TIMESTAMPTZ DEFAULT NOW(),
  activation_token    TEXT DEFAULT NULL,
  banned              INTEGER DEFAULT 0,
  ban_reason          TEXT DEFAULT NULL,
  banned_at           TIMESTAMPTZ DEFAULT NULL,
  premium_expires_at  TIMESTAMPTZ DEFAULT NULL,
  reset_telegram_code TEXT DEFAULT NULL,
  reset_code_expires  TIMESTAMPTZ DEFAULT NULL,
  referral_count      INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bots (
  id                  TEXT PRIMARY KEY,
  user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  token               TEXT NOT NULL,
  library             TEXT DEFAULT 'telebot_sync',
  status              TEXT DEFAULT 'stopped',
  file_path           TEXT,
  storage_used        BIGINT DEFAULT 0,
  pid                 INTEGER DEFAULT NULL,
  restart_count       INTEGER DEFAULT 0,
  uptime_start        BIGINT DEFAULT NULL,
  notes               TEXT DEFAULT NULL,
  scheduled_restart   TEXT DEFAULT NULL,
  crash_notified      INTEGER DEFAULT 0,
  proxy_enabled       INTEGER DEFAULT 0,
  entry_file          TEXT DEFAULT NULL,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS logs (
  id          SERIAL PRIMARY KEY,
  bot_id      TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
  message     TEXT NOT NULL,
  level       TEXT DEFAULT 'info',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_logs_bot_id ON logs(bot_id, id DESC);

CREATE TABLE IF NOT EXISTS activation_tokens (
  id                SERIAL PRIMARY KEY,
  token             TEXT UNIQUE NOT NULL,
  telegram_id       TEXT UNIQUE NOT NULL,
  telegram_username TEXT,
  used_by           INTEGER DEFAULT NULL REFERENCES users(id) ON DELETE SET NULL,
  referred_by       TEXT DEFAULT NULL,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  used_at           TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS ddos_logs (
  id          SERIAL PRIMARY KEY,
  ip          TEXT NOT NULL,
  country     TEXT DEFAULT 'XX',
  cf_ray      TEXT,
  hits        INTEGER DEFAULT 0,
  path        TEXT,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ban_history (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  action          TEXT NOT NULL,
  reason          TEXT,
  admin_username  TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS proxies (
  id                SERIAL PRIMARY KEY,
  host              TEXT NOT NULL,
  port              INTEGER NOT NULL,
  username          TEXT,
  password          TEXT,
  raw               TEXT NOT NULL,
  assigned_user_id  INTEGER DEFAULT NULL REFERENCES users(id) ON DELETE SET NULL,
  status            TEXT DEFAULT 'alive',
  added_by          TEXT,
  last_checked_at   TIMESTAMPTZ DEFAULT NULL,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS proxy_requests (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message      TEXT,
  status       TEXT DEFAULT 'pending',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  resolved_at  TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS email_codes (
  id          SERIAL PRIMARY KEY,
  email       TEXT NOT NULL,
  code        TEXT NOT NULL,
  type        TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  used        INTEGER DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS login_attempts (
  id          SERIAL PRIMARY KEY,
  identifier  TEXT NOT NULL,
  ip          TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS announcements (
  id          SERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  photo_url   TEXT DEFAULT NULL,
  active      INTEGER DEFAULT 1,
  created_by  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bot_env_vars (
  id          SERIAL PRIMARY KEY,
  bot_id      TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
  key         TEXT NOT NULL,
  value       TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (bot_id, key)
);

CREATE TABLE IF NOT EXISTS referrals (
  id             SERIAL PRIMARY KEY,
  referrer_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  days_credited  INTEGER DEFAULT 1,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS billing_history (
  id            SERIAL PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_key      TEXT,
  plan_label    TEXT NOT NULL,
  amount_label  TEXT,
  action        TEXT NOT NULL DEFAULT 'grant',
  granted_by    TEXT,
  starts_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);
