# Themes

The site has a theme switcher (bottom-left on every page). Visitors can choose
between themes, and the choice is saved in a cookie.

## Built-in themes

- **Cyberpunk City** (default): neon skyline, rain, constellation dots, floating
  tech keywords, and a bot flying across the sky.
- **Classic**: the original design.

Light/dark mode still works inside the Classic theme.

## Switching the default theme

Edit `public/assets/theme-loader.js`:

```js
var DEFAULT_PACK = 'cyberpunk';   // change to 'default' for Classic
```

## Adding your own theme

1. Create two files in `public/assets/packs/`:
   - `mytheme.css`: colors and styling, scoped to `html[data-pack="mytheme"]`.
   - `mytheme.js` (optional): an animated background. It must register itself:
     ```js
     window.VoidPacks = window.VoidPacks || {};
     window.VoidPacks.mytheme = {
       start: function () { /* create your background */ },
       stop:  function () { /* remove it */ }
     };
     ```
2. Add it to the `PACKS` list in `public/assets/theme-loader.js`:
   ```js
   mytheme: { label: 'My Theme', css: '/assets/packs/mytheme.css', js: '/assets/packs/mytheme.js' },
   ```
   Use `css: null` or `js: null` if you don't need one.

The switcher picks up the new entry automatically.

## Tips

- Copy `packs/cyberpunk.css` as a starting point. It defines the variables
  (`--accent`, `--surface`, `--font-strong`, and so on) that the pages use.
- Keep animated backgrounds light. The loader calls `stop()` when the visitor
  switches away, so clean up any timers, listeners, and DOM elements there.
- The scene uses `position: fixed; z-index: -1`, so it sits behind the page.
