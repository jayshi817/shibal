// services/codeScanner.js — static scanner for user-uploaded bot code.
//
// Blocks code that tries to hijack the host or take the site down, and code
// that hides its logic behind decode / base64 / eval-style tricks.
// Bot tokens are never read or scanned.
//
// This is a rule-based scanner (no external AI call). It runs at upload/save
// time and returns { ok, findings }. ok=false means the upload is rejected.

const fs = require('fs');
const path = require('path');

const SCANNABLE_EXT = ['.py', '.js', '.mjs', '.cjs', '.ts', '.txt', '.json', '.cfg', '.ini', '.toml', '.sh'];
const MAX_SCAN_BYTES = 5 * 1024 * 1024;

// Each rule: id, severity ('block' rejects the upload), description, regex.
const RULES = [
  // ── Hijack / sabotage of the host or the site ────────────────────
  { id: 'kill-other', severity: 'block', desc: 'Tries to kill or signal other processes',
    re: /\b(os\.kill|os\.killpg|signal\.SIGKILL|subprocess\.[a-z]+\(\s*\[?\s*['"]?(pkill|killall)\b|\bpkill\b|\bkillall\b)/i },
  { id: 'platform-files', severity: 'block', desc: 'Touches the platform source or data folders',
    re: /(\/app\/(server|routes|engine|middleware|services)|\/data\/(uploads|extracted)|\b(server|database)\.js\b|engine\/botRunner|schema\.sql|\.nixpacks)/i },
  { id: 'platform-env', severity: 'block', desc: 'Reads platform secrets from the environment',
    re: /(DATABASE_URL|SESSION_SECRET|ADMIN_PASSWORD|ADMIN_USERNAME|RESEND_API_KEY|PGPASSWORD)/ },
  { id: 'parent-escape', severity: 'block', desc: 'Tries to walk outside its own folder',
    re: /(\.\.\/\.\.|\.\.\\\.\.|os\.chdir\(\s*['"]\/|shutil\.rmtree\(\s*['"]\/|fs\.rmSync\(\s*['"]\/)/ },
  { id: 'destructive', severity: 'block', desc: 'Destructive command against the whole system',
    re: /(rm\s+-rf\s+\/(\s|$|\*)|mkfs\.|dd\s+if=.*of=\/dev\/|:\(\)\s*\{\s*:\|:&\s*\};:|shutil\.rmtree\(\s*['"]\/['"])/ },
  { id: 'reverse-shell', severity: 'block', desc: 'Looks like a reverse shell or remote shell',
    re: /(\/dev\/tcp\/|bash\s+-i\s*>&|nc\s+(-e|-c)\s|ncat\s.*-e\s|pty\.spawn\(\s*['"]\/bin\/(ba)?sh)/i },
  { id: 'network-scan', severity: 'block', desc: 'Network scanning or DDoS tooling',
    re: /\b(nmap|masscan|hping3|slowloris|loic|hulk)\b|socket\.socket\([^)]*\)[\s\S]{0,200}range\(\s*1\s*,\s*6553[56]/i },
  { id: 'miner', severity: 'block', desc: 'Cryptocurrency miner',
    re: /(xmrig|stratum\+tcp:\/\/|cryptonight|coinhive)/i },

  // ── Hidden logic: decode / base64 / eval tricks ──────────────────
  { id: 'base64', severity: 'block', desc: 'Uses base64 encoding or decoding',
    re: /(base64\.(b64decode|b64encode|urlsafe_b64decode|decodebytes|decodestring|encodebytes)|\bb64decode\b|\bb64encode\b|\batob\s*\(|\bbtoa\s*\(|Buffer\.from\([^)]*['"]base64['"]|\.decode\(\s*['"]base64['"])/ },
  { id: 'decode', severity: 'block', desc: 'Uses decode or unhex tricks to hide code',
    re: /(codecs\.decode\s*\(|binascii\.(un)?hexlify|binascii\.a2b_|bytes\.fromhex\(|\.fromCharCode\s*\(|\bunhexlify\b|\bhex2bin\b|\bzlib\.decompress\s*\(|\bmarshal\.loads\s*\()/ },
  { id: 'dynamic-exec', severity: 'block', desc: 'Runs dynamically built code (exec or eval)',
    re: /(?<![\w.])(exec|eval|compile)\s*\(|\bnew\s+Function\s*\(|\bvm\.(runIn|Script)/ },
  { id: 'import-hide', severity: 'block', desc: 'Imports modules dynamically to hide what runs',
    re: /(__import__\s*\(|importlib\.import_module\s*\(|require\s*\(\s*[^'"\s)]+\s*\))/ },
];

function scanText(name, text) {
  const findings = [];
  for (const rule of RULES) {
    const m = rule.re.exec(text);
    if (m) {
      const lineNo = text.slice(0, m.index).split('\n').length;
      findings.push({ file: name, line: lineNo, rule: rule.id, severity: rule.severity, desc: rule.desc, match: m[0].slice(0, 60) });
    }
  }
  return findings;
}

function isScannable(name) {
  return SCANNABLE_EXT.includes(path.extname(name).toLowerCase());
}

// Scan one file on disk.
function scanFile(filePath, displayName) {
  const name = displayName || path.basename(filePath);
  if (!isScannable(name)) return [];
  const st = fs.statSync(filePath);
  if (st.size > MAX_SCAN_BYTES) {
    return [{ file: name, line: 0, rule: 'too-large', severity: 'block', desc: 'File too large to verify', match: '' }];
  }
  return scanText(name, fs.readFileSync(filePath, 'utf8'));
}

// Scan a ZIP archive without extracting it to disk.
function scanZip(zipPath) {
  const AdmZip = require('adm-zip');
  const zip = new AdmZip(zipPath);
  const findings = [];
  for (const entry of zip.getEntries()) {
    if (entry.isDirectory || !isScannable(entry.entryName)) continue;
    const data = entry.getData();
    if (data.length > MAX_SCAN_BYTES) {
      findings.push({ file: entry.entryName, line: 0, rule: 'too-large', severity: 'block', desc: 'File too large to verify', match: '' });
      continue;
    }
    findings.push(...scanText(entry.entryName, data.toString('utf8')));
  }
  return findings;
}

// Entry point used by routes. Pass a disk path to a .py or .zip file.
function scanUpload(filePath, originalName) {
  const name = originalName || path.basename(filePath);
  const findings = name.toLowerCase().endsWith('.zip') ? scanZip(filePath) : scanFile(filePath, name);
  const blocked = findings.filter(f => f.severity === 'block');
  return { ok: blocked.length === 0, findings, blocked };
}

// Human-readable message for the user. Never includes the matched text
// beyond a short excerpt, and never mentions tokens.
function describe(result) {
  const first = result.blocked[0];
  if (!first) return '';
  return `Upload blocked: ${first.desc} (${first.file}, line ${first.line}).`;
}

module.exports = { scanUpload, scanText, describe, RULES };
