const RESEND_KEY = process.env.RESEND_API_KEY;
const FROM = process.env.MAIL_FROM || 'VØĪD HØSTÏÑG <noreply@nixzhosting.com>';

async function sendMail({ to, subject, html }) {
  if (!RESEND_KEY) { console.log(`[MAIL] No key — skip email to ${to}`); return { ok: false }; }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${RESEND_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: FROM, to, subject, html })
    });
    const data = await res.json();
    if (!res.ok) { console.error('[MAIL] Resend error:', data); return { ok: false }; }
    return { ok: true };
  } catch (err) { console.error('[MAIL] error:', err.message); return { ok: false }; }
}

function wrap(inner) {
  return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#080808;font-family:'Inter',Arial,sans-serif"><div style="max-width:460px;margin:40px auto;background:#101010;border:1px solid #1e1e1e;padding:40px"><div style="font-size:1rem;font-weight:600;color:#f5f5f5;margin-bottom:4px">VØĪD HØSTÏÑG</div><div style="font-size:.65rem;letter-spacing:2px;text-transform:uppercase;color:#606060;margin-bottom:32px">Hosting Platform</div>${inner}<div style="margin-top:32px;font-size:.68rem;color:#3a3a3a">If you did not request this, ignore this email.</div></div></body></html>`;
}

function codeEmail({ code, type, username }) {
  const titles = { verify: 'Verify your email address', login: 'Login verification code', reset: 'Password reset code' };
  const bodies = { verify: `Hi ${username}, enter this code to confirm your email address.`, login: `Hi ${username}, a login attempt was made. Enter this code to proceed.`, reset: `Hi ${username}, use this code to reset your password. Expires in 15 minutes.` };
  return wrap(`<div style="font-size:1rem;font-weight:600;color:#f5f5f5;margin-bottom:8px">${titles[type]||titles.verify}</div><div style="font-size:.82rem;color:#606060;line-height:1.6;margin-bottom:28px">${bodies[type]||bodies.verify}</div><div style="background:#080808;border:1px solid #272727;padding:24px;text-align:center;margin-bottom:8px"><span style="font-size:2.6rem;font-weight:600;letter-spacing:14px;color:#f5f5f5;font-family:'Courier New',monospace">${code}</span></div><div style="font-size:.68rem;color:#3a3a3a">Expires in 15 minutes.</div>`);
}

function crashEmail({ username, botName, errorLine }) {
  return wrap(`<div style="font-size:1rem;font-weight:600;color:#ef4444;margin-bottom:8px">Bot Crashed</div><div style="font-size:.82rem;color:#606060;line-height:1.6;margin-bottom:20px">Hi <strong style="color:#f5f5f5">${username}</strong>, your bot <strong style="color:#f5f5f5">${botName}</strong> has stopped unexpectedly.</div>${errorLine?`<div style="background:#080808;border-left:2px solid #ef4444;padding:12px 14px;margin-bottom:20px;font-family:'Courier New',monospace;font-size:.72rem;color:#fca5a5;word-break:break-all">${errorLine}</div>`:''}<a href="${process.env.NIXZ_URL||''}/dashboard" style="display:inline-block;background:#f5f5f5;color:#080808;padding:10px 20px;font-size:.68rem;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;text-decoration:none">View Dashboard</a>`);
}

function planExpiryEmail({ username, plan, expiresAt }) {
  return wrap(`<div style="font-size:1rem;font-weight:600;color:#eab308;margin-bottom:8px">Plan Expiring Soon</div><div style="font-size:.82rem;color:#606060;line-height:1.6;margin-bottom:20px">Hi <strong style="color:#f5f5f5">${username}</strong>, your <strong style="color:#f5f5f5">${plan}</strong> plan expires on <strong style="color:#f5f5f5">${expiresAt}</strong>. Renew before then to keep your bots running without interruption.</div><a href="https://t.me/VOIDv24" style="display:inline-block;background:#f5f5f5;color:#080808;padding:10px 20px;font-size:.68rem;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;text-decoration:none">Renew via Telegram</a>`);
}

module.exports = { sendMail, codeEmail, crashEmail, planExpiryEmail };
