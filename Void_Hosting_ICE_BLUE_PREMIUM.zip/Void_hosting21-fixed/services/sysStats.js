// services/sysStats.js — live host metrics for the admin monitor.
// CPU % is computed from the delta between calls. GPU comes from nvidia-smi
// when it exists; otherwise it reports unavailable. Network speed is read from
// /proc/net/dev. Telegram latency is a timed HTTPS request, cached briefly.

const os = require('os');
const fs = require('fs');
const https = require('https');
const { execFile } = require('child_process');

let lastCpu = null;
function cpuSample() {
  let idle = 0, total = 0;
  for (const c of os.cpus()) {
    for (const k of Object.keys(c.times)) total += c.times[k];
    idle += c.times.idle;
  }
  return { idle, total };
}
function cpuPercent() {
  const now = cpuSample();
  if (!lastCpu) { lastCpu = now; return null; }
  const dIdle = now.idle - lastCpu.idle;
  const dTotal = now.total - lastCpu.total;
  lastCpu = now;
  if (dTotal <= 0) return 0;
  return Math.round((1 - dIdle / dTotal) * 1000) / 10;
}

let lastNet = null;
function readNetBytes() {
  try {
    const lines = fs.readFileSync('/proc/net/dev', 'utf8').split('\n').slice(2);
    let rx = 0, tx = 0;
    for (const l of lines) {
      const [name, rest] = l.split(':');
      if (!rest || name.trim() === 'lo') continue;
      const f = rest.trim().split(/\s+/);
      rx += parseInt(f[0], 10) || 0;
      tx += parseInt(f[8], 10) || 0;
    }
    return { rx, tx, t: Date.now() };
  } catch { return null; }
}
function networkSpeed() {
  const now = readNetBytes();
  if (!now) return { available: false };
  if (!lastNet) { lastNet = now; return { available: true, down_kbps: null, up_kbps: null }; }
  const secs = (now.t - lastNet.t) / 1000 || 1;
  const out = {
    available: true,
    down_kbps: Math.round((now.rx - lastNet.rx) / secs / 1024 * 10) / 10,
    up_kbps: Math.round((now.tx - lastNet.tx) / secs / 1024 * 10) / 10,
  };
  lastNet = now;
  return out;
}

function gpuInfo() {
  return new Promise(resolve => {
    execFile('nvidia-smi',
      ['--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu', '--format=csv,noheader,nounits'],
      { timeout: 2000 },
      (err, stdout) => {
        if (err || !stdout) return resolve({ available: false, gpus: [] });
        const gpus = stdout.trim().split('\n').map(line => {
          const [name, util, memUsed, memTotal, temp] = line.split(',').map(s => s.trim());
          return {
            name,
            utilization: parseFloat(util),
            memory_used_mb: parseFloat(memUsed),
            memory_total_mb: parseFloat(memTotal),
            temperature_c: parseFloat(temp),
          };
        });
        resolve({ available: true, gpus });
      });
  });
}

let tgCache = { at: 0, value: null };
function telegramLatency() {
  return new Promise(resolve => {
    if (Date.now() - tgCache.at < 10000 && tgCache.value !== null) return resolve(tgCache.value);
    const start = Date.now();
    const req = https.request({ host: 'api.telegram.org', path: '/', method: 'HEAD', timeout: 3000 }, res => {
      res.resume();
      const ms = Date.now() - start;
      tgCache = { at: Date.now(), value: ms };
      resolve(ms);
    });
    req.on('timeout', () => { req.destroy(); tgCache = { at: Date.now(), value: -1 }; resolve(null); });
    req.on('error', () => { tgCache = { at: Date.now(), value: -1 }; resolve(null); });
    req.end();
  });
}

async function snapshot() {
  const total = os.totalmem();
  const free = os.freemem();
  const gpu = await gpuInfo();
  const tg = await telegramLatency();
  return {
    timestamp: Date.now(),
    cpu: {
      percent: cpuPercent(),
      cores: os.cpus().length,
      model: os.cpus()[0] ? os.cpus()[0].model : null,
      load_1m: os.loadavg()[0],
    },
    memory: {
      used_mb: Math.round((total - free) / 1048576),
      total_mb: Math.round(total / 1048576),
      percent: Math.round(((total - free) / total) * 1000) / 10,
    },
    gpu,
    network: networkSpeed(),
    speed: {
      telegram_latency_ms: tg === -1 ? null : tg,
      telegram_reachable: tg !== null && tg !== -1,
    },
    uptime_s: Math.round(process.uptime()),
  };
}

module.exports = { snapshot };
